package Sprint2;

import javafx.stage.*;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javafx.geometry.Insets;

public class Cliente{
    public static void mostrar(){
        Stage ventana = new Stage();

        ventana.initModality(Modality.APPLICATION_MODAL);
        ventana.setTitle("Ventana de ingreso del Cliente");
        ventana.setMinWidth(500);

        GridPane panel = new GridPane();
        panel.setPadding(new Insets(60, 60, 0, 16));
        panel.setVgap(10); //filas
        panel.setHgap(10); //columnas
        
        //NOMBRE EN TEXTFIELD
        Label textoUsuario = new Label("Nombre: ");
        GridPane.setConstraints(textoUsuario, 0, 1);
        TextField entradaUsuario = new TextField(" ");
        GridPane.setConstraints(entradaUsuario, 1, 1);

        //RUT EN TEXTFIELD
        Label textoRut = new Label("RUT incluido guion: ");
        GridPane.setConstraints(textoRut, 2, 1);
        TextField rut = new TextField(" ");
        GridPane.setConstraints(rut, 3, 1);

        //EDAD EN TEXTFIELD
        Label textoedad = new Label("Edad: ");
        GridPane.setConstraints(textoedad, 0, 2);
        TextField edad = new TextField(" ");
        GridPane.setConstraints(edad, 1, 2);

        //N casa en textfield
        Label textocasa= new Label("N Casa: ");
        GridPane.setConstraints(textocasa, 2, 2);
        TextField casa= new TextField(" ");
        GridPane.setConstraints(casa, 3, 2);

        //SEXO EN CHOICEBOX, solo me dio paja cambiar los nombres de las variables
        Label textoGenero = new Label("Sexo: ");
        GridPane.setConstraints(textoGenero, 0, 3);
        ChoiceBox<String> genero = new ChoiceBox<>();
            genero.getItems().addAll("Hombre", "Mujer","N/A");
            genero.setValue("N/A");
            GridPane.setConstraints(genero, 1, 3);

        Label lista = new Label();

        //N telefonico en textfield
        Label textonumero= new Label("N Telefonico: ");
        GridPane.setConstraints(textonumero, 2, 3);
        TextField numero= new TextField(" ");
        GridPane.setConstraints(numero, 3, 3);

        //Registrar el cliente
        Button agregar = new Button("Registrar");
        agregar.setOnAction(e -> {
                try {
                    FileWriter escritor = new FileWriter("clientes.txt",true);
                    escritor.write("\n\nnombre de cliente: "+entradaUsuario.getText());
                    escritor.write("\nRut:"+rut.getText());
                    escritor.write("\nEdad:"+edad.getText());
                    escritor.write("\ncasa:"+casa.getText());
                    escritor.write("\ngenero:"+genero.getValue());
                    escritor.write("\nnumero telefonico:"+numero.getText());
                    escritor.write("\napodo de cliente:"+entradaUsuario.getText());
                    escritor.close();
                       
                } catch (Exception i) {
                    System.out.println("ocurrio un error");
            }
        });
        GridPane.setConstraints(agregar, 3, 4);

        panel.getChildren().addAll(textoUsuario, entradaUsuario, textoedad, edad, textoRut, rut, textocasa, casa, textoGenero, genero, textonumero, numero, agregar);

        //TITULO EN VBOX
        Label titulo = new Label("Datos del Cliente:");
        titulo.setTranslateX(50);
        titulo.setTranslateY(35);
        titulo.setTextFill(Color.rgb(41, 128, 185));
        titulo.setFont(Font.font("FangSong", FontWeight.NORMAL, FontPosture.REGULAR, 25.0));
        
        VBox todo = new VBox(2);
        todo.setPadding(new Insets(10,10,10,10));
        todo.getChildren().addAll(titulo, panel);
        Scene tema = new Scene(todo, 700, 400);
        ventana.setScene(tema);
        ventana.showAndWait();
    }
    private static boolean esEntero(String mensaje){
        try{
            //toda la rutina a probar
            int edad = Integer.parseInt(mensaje);
            return true;
        }catch(NumberFormatException o){
            //hacer una rutina de manejo de error
            return false;
        }
    }
}