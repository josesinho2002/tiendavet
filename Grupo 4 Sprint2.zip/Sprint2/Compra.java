package Sprint2;

import javafx.stage.*;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.*;
import javafx.geometry.Insets;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Compra {
    
    public static void mostrar(){
        Stage ventana = new Stage();

        ventana.initModality(Modality.APPLICATION_MODAL);
        ventana.setTitle("Ventana de compra");
        ventana.setMinWidth(700);

        GridPane grid = new GridPane();

        grid.setVgap(13);//altura de espacios en filas
        grid.setHgap(10);//espacios en columnas
        grid.setPadding(new Insets(30, 10, 10, 90));//margen

        Label titulo = new Label("Listado de productos a comprar:");
        titulo.setTextFill(Color.rgb(41, 128, 185));
        titulo.setFont(Font.font("FangSong", FontWeight.NORMAL, FontPosture.REGULAR, 25.0));

        Label aseo = new Label("Productos de aseo: ");
        Label Prendas = new Label("Productos Esteticos y Prendas:");
        Label Accesorios = new Label(" Accesorios:");
        Label Alimentos = new Label("Alimentos:");
        TextField entradas = new TextField();
        TextField entradap = new TextField();
        TextField entradac = new TextField();
        TextField entradal = new TextField();        
        entradas.setPromptText("0");
        entradap.setPromptText("0");
        entradac.setPromptText("0");
        entradal.setPromptText("0");
        Button boton = new Button("Realizar compra");
        boton.setOnAction(e->{
            File archivo = new File("stock.txt");
            if(archivo.exists()){
                if(esEntero(entradas.getText())&&esEntero(entradap.getText())&&esEntero(entradac.getText())&&esEntero(entradal.getText())){
                    try {
                        Scanner lector = new Scanner(archivo);
    
                        String linea = lector.nextLine();
                        String[] palabras = linea.split(":");
                        int a = Integer.parseInt(palabras[1]);
    
                        linea = lector.nextLine();
                        String[] palabrass = linea.split(":");
                        int b = Integer.parseInt(palabrass[1]);
    
                        linea = lector.nextLine();
                        String[] palabrasss = linea.split(":");
                        int c = Integer.parseInt(palabrasss[1]);
    
                        linea = lector.nextLine();
                        String[] palabrassss = linea.split(":");
                        int d = Integer.parseInt(palabrassss[1]);
    
                        lector.close();
                        
                        if(Integer.parseInt(entradas.getText())<=a &&Integer.parseInt(entradap.getText())<=b&&Integer.parseInt(entradac.getText())<=c &&Integer.parseInt(entradal.getText())<=d){
                            if(Integer.parseInt(entradas.getText())>=0 &&Integer.parseInt(entradap.getText())>=0&&Integer.parseInt(entradac.getText())>=0 &&Integer.parseInt(entradal.getText())>=0){
                                File clientesss = new File("clientes.txt");
                            if(clientesss.exists()){
                            FileWriter escritor = new FileWriter("stock.txt");
                            escritor.write("Productos de aseo:"+(a-Integer.parseInt(entradas.getText())));
                            escritor.write("\nProductos Esteticos y Prendas:"+(b-Integer.parseInt(entradap.getText())));
                            escritor.write("\nAccesorios:"+(c-Integer.parseInt(entradac.getText())));
                            escritor.write("\nAlimentos:"+(d-Integer.parseInt(entradal.getText())));
                            escritor.close();

                            FileWriter boleta = new FileWriter("boleta.txt",true);
                            boleta.write("\n\nBoleta:");
                        
                            Scanner lectorrr = new Scanner(clientesss);
                            while(lectorrr.hasNextLine()){
                                linea = lectorrr.nextLine();
                            }
                            String[] palabrastr = linea.split(":");
                            boleta.write("\nCliente:"+palabrastr[1]);

                            int valorboleta=0;
                            //(cliente)
                            if(Integer.parseInt(entradas.getText())>0){ //precio aseo  3000
                                valorboleta = valorboleta+3000*Integer.parseInt(entradas.getText());
                                boleta.write("\nProductos de aseo comprados:"+entradas.getText()+"   "+(3000*Integer.parseInt(entradas.getText())));
                            }
                            if(Integer.parseInt(entradap.getText())>0){  //precio prendas  6000
                                valorboleta = valorboleta+6000*Integer.parseInt(entradap.getText());
                                boleta.write("\nProductos Esteticos y Prendas comprados:"+entradap.getText()+"   "+(6000*Integer.parseInt(entradap.getText())));
                            }
                            if(Integer.parseInt(entradac.getText())>0){  //precio accesorios  7000
                                valorboleta = valorboleta+7000*Integer.parseInt(entradac.getText());
                                boleta.write("\nAccesorios comprados:"+entradac.getText()+"   "+(7000*Integer.parseInt(entradac.getText())));
                            }
                            if(Integer.parseInt(entradal.getText())>0){  //precio alimentos  5000
                                valorboleta = valorboleta+5000*Integer.parseInt(entradal.getText());
                                boleta.write("\nAlimentos comprados:"+entradal.getText()+"   "+(5000*Integer.parseInt(entradal.getText())));
                            }
                            boleta.write("\nValor de la compra:"+valorboleta);

                            boleta.close();
                        }
                        else{
                            System.out.println("no hay stock disponible, por favor actualicelo");
                        }
                    }
                            }
                            //
                        } 
                        catch (Exception o) {
                            System.out.println("algo salio mal");
                            //TODO: handle exception
                        }
                }
                else{
                    System.out.println("uno o mas valores ingresados no son enteros, reviselos por favor");
                }
            }
        });
        
        GridPane.setConstraints(titulo, 1, 0);
        GridPane.setConstraints(aseo, 1, 2);
        GridPane.setConstraints(Prendas, 1, 3);
        GridPane.setConstraints(Accesorios, 1, 4);
        GridPane.setConstraints(Alimentos, 1, 5);
        GridPane.setConstraints(entradas, 2, 2);
        GridPane.setConstraints(entradap, 2, 3);
        GridPane.setConstraints(entradac, 2, 4);
        GridPane.setConstraints(entradal, 2, 5);
        GridPane.setConstraints(boton, 2, 6);

        grid.getChildren().addAll(titulo,aseo,Prendas,Accesorios,Alimentos,entradas,entradap,entradac,entradal,boton);

        Scene tema = new Scene(grid, 700, 400);
        ventana.setScene(tema);
        ventana.showAndWait();
    }
    private static boolean esEntero(String mensaje){
        try{
            //toda la rutina a probar
            int edad = Integer.parseInt(mensaje);
            return true;
        }catch(NumberFormatException o){
            //hacer una rutina de manejo de error
            return false;
        }
    }
}