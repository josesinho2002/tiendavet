package Sprint2;

import javafx.stage.*;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javafx.geometry.Insets;

public class Stock {
    
    public static void mostrar(){
        Stage ventana = new Stage();

        ventana.initModality(Modality.APPLICATION_MODAL);
        ventana.setTitle("Ventana de reponer stock");
        ventana.setMinWidth(500);

        GridPane g1 = new GridPane();
        int x=700, y=400;

        g1.setVgap(13);//altura de espacios en filas
        g1.setHgap(15);//espacios en columnas
        g1.setPadding(new Insets(30, 10, 10, 50));//margen

        Label l1 = new Label("Ingrese la seccion a la que desea reponer el stock:");
        l1.setTranslateX(50);
        l1.setTranslateY(35);
        l1.setTextFill(Color.rgb(41, 128, 185));
        l1.setFont(Font.font("FangSong", FontWeight.NORMAL, FontPosture.REGULAR, 23.0));
        
        Label l2 = new Label("Reponer el Stock de Productos de aseo: ");
        Label l3 = new Label("Reponer el Stock de Productos Esteticos y Prendas:");
        Label l4 = new Label("Reponer el Stock de Accesorios:");
        Label l5 = new Label("Reponer el Stock de Alimentos:");
        TextField t1 = new TextField();
        TextField t2 = new TextField();
        TextField t3 = new TextField();
        TextField t4 = new TextField();        
        t1.setPromptText("Ingrese un valor");
        t2.setPromptText("Ingrese un valor");
        t3.setPromptText("Ingrese un valor");
        t4.setPromptText("Ingrese un valor");
        Button t5 = new Button("Ingresar nuevo stock");
        t5.setOnAction(e->{
            if(esEntero(t1.getText())&&esEntero(t2.getText())&&esEntero(t3.getText())&&esEntero(t4.getText())){
                try {
                    FileWriter escritor = new FileWriter("stock.txt");
                    escritor.write("Productos de aseo:"+t1.getText());
                    escritor.write("\nProductos Esteticos y Prendas:"+t2.getText());
                    escritor.write("\nAccesorios:"+t3.getText());
                    escritor.write("\nAlimentos:"+t4.getText());
                    escritor.close();
                       
                } catch (Exception i) {
                    System.out.println("ocurrio un error");
                }
            }
            else{
                System.out.println("no ha ingresado enteros, porfavor revise los numeros ingresados");
            }
        });
        
        GridPane.setConstraints(l2, 0, 1);
        GridPane.setConstraints(l3, 0, 2);
        GridPane.setConstraints(l4, 0, 3);
        GridPane.setConstraints(l5, 0, 4);
        GridPane.setConstraints(t1, 1, 1);
        GridPane.setConstraints(t2, 1, 2);
        GridPane.setConstraints(t3, 1, 3);
        GridPane.setConstraints(t4, 1, 4);
        GridPane.setConstraints(t5, 1, 5);

        g1.getChildren().addAll(l2,l3,l4,l5,t1,t2,t3,t4,t5);

        VBox vbox = new VBox(l1,g1);
        vbox.setSpacing(25);

        Scene tema = new Scene(vbox, x, y);
        ventana.setScene(tema);
        ventana.showAndWait();
    }
    private static boolean esEntero(String mensaje){
        try{
            //toda la rutina a probar
            int edad = Integer.parseInt(mensaje);
            return true;
        }catch(NumberFormatException o){
            //hacer una rutina de manejo de error
            return false;
        }
    }
}