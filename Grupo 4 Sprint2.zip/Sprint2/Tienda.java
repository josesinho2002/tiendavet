package Sprint2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Tienda extends Application{
    String ID = "123456";
    Stage ventana;
    Scene tema1, tema2;
    public static void main(String[] args)
    {
        launch(args);
    }

    @Override 
    public void start(Stage primaryStage) throws Exception{
        ventana = primaryStage;
        
        primaryStage.setTitle("Tienda De Mascotas");

        Label titulo = new Label("Bienvenido a la tienda de mascotas");
        titulo.setTextFill(Color.rgb(41, 128, 185));
        titulo.setFont(Font.font("FangSong", FontWeight.NORMAL, FontPosture.REGULAR, 30.0));
        
        Label id = new Label("Ingrese con su ID:");
        TextField entradaID = new TextField("");
        entradaID.setPrefWidth(10);
        entradaID.setMaxWidth(200);                

        Button boton1 = new Button("Ingresar");

        boton1.setOnAction(e -> {
            if(entradaID.getText().equals(ID)){
                ventana.setScene(tema2);
            }
            else{
                System.out.println("id incorrecta");
            }
        });
        
        GridPane panel1 = new GridPane();
        //                            v          > 
        panel1.setPadding(new Insets(60, 10, 40, 70));
        panel1.setVgap(15);
        panel1.setHgap(5);
        GridPane.setConstraints(titulo, 4, 0);
        GridPane.setConstraints(id, 4, 1);
        GridPane.setConstraints(entradaID, 4, 2);
        GridPane.setConstraints(boton1, 4, 3);        
        
        panel1.getChildren().addAll(titulo,id,entradaID, boton1);
        tema1 = new Scene(panel1,700,400);
                
        Label idIn = new Label("ID ingresada:\n" + ID);
        idIn.setTextFill(Color.rgb(41, 128, 185));
        idIn.setFont(Font.font("FangSong", FontWeight.NORMAL, FontPosture.REGULAR, 20.0));
        
        Button boton2 = new Button("Salir");
        boton2.setMinSize(130, 40);        
        Button registrar = new Button("Ingresar Datos \ndel Cliente");
        registrar.setMinSize(130, 60); 
        Button reponer= new Button("Reponer Stock de \na Lista de productos");
        reponer.setMinSize(130, 60); 
        Button compra = new Button("Ingresar a la Caja\n para la compra");
        compra.setMinSize(130, 60); 

        boton2.setOnAction(e -> ventana.setScene(tema1));
        registrar.setOnAction(e ->{
            Cliente.mostrar();
        });
        reponer.setOnAction(e ->{
           Stock.mostrar();
        });
        compra.setOnAction(e ->{
            Compra.mostrar();
        });
        GridPane.setConstraints(idIn, 0, 0);
        GridPane.setConstraints(boton2, 4, 10);
        GridPane.setConstraints(registrar, 2, 4);
        GridPane.setConstraints(reponer, 4, 4);
        GridPane.setConstraints(compra, 6, 4);

        GridPane panel2 = new GridPane();
        panel2.setPadding(new Insets(10, 10, 10, 10));
        panel2.setVgap(15);
        panel2.setHgap(5);
        panel2.getChildren().addAll(idIn,boton2,registrar,reponer,compra);
        tema2 = new Scene(panel2, 700, 400);
        
        ventana.setScene(tema1);
        primaryStage.show();
    }
}